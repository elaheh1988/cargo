from openpyxl import load_workbook
import csv
import os

# Load the workbook
wb = load_workbook('product.xlsx')
ws = wb.active

# Get all data rows (skipping the header)
data_rows = list(ws.iter_rows(min_row=2, values_only=True))

print(f"Total products: {len(data_rows)}")

# Define category keywords (in Persian/Arabic)
categories = {
    "Fruits": ['آناناس', 'سیب', 'پرتقال', 'انگور', 'میوه', 'خرما', 'انبه', 'موز', 'گیلاس'],
    "Vegetables": ['مارچوبه', 'لوبیا', 'عدس', 'سبزیجات', 'ذرت', 'کاهو', 'هویج', 'گوجه'],
    "Meat": ['گوشت', 'مرغ', 'ماهی', 'گوساله', 'گوسفند'],
    "Dairy": ['شیر', 'پنیر', 'ماست', 'کره', 'خامه'],
    "Electronics": ['برقی', 'الکترونیکی', 'تلفن', 'کامپیوتر', 'رایانه', 'لپ تاپ', 'تلویزیون', 'الکتریکی'],
    "Clothing": ['لباس', 'پوشاک', 'پارچه', 'کفش', 'کتان', 'نساجی', 'پنبه'],
    "Household": ['خانگی', 'آشپزخانه', 'مبلمان', 'فرش', 'منزل'],
    "Tools": ['ابزار', 'دستگاه', 'ماشین آلات', 'آلات'],
}

# Create a dictionary to store categorized products
categorized_products = {category: [] for category in categories}
uncategorized = []

# Categorize products
for row in data_rows:
    product_name, tariff_code, index = row
    if not product_name:
        continue
    
    # Check which category the product belongs to
    categorized = False
    for category, keywords in categories.items():
        if any(keyword in product_name for keyword in keywords):
            categorized_products[category].append({
                'name': product_name,
                'tariff_code': tariff_code,
                'index': index
            })
            categorized = True
    
    if not categorized:
        uncategorized.append({
            'name': product_name,
            'tariff_code': tariff_code,
            'index': index
        })

# Create output directory if it doesn't exist
output_dir = 'categorized_products'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Export each category to a separate CSV file
for category, products in categorized_products.items():
    if products:
        filename = os.path.join(output_dir, f"{category}_products.csv")
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['name', 'tariff_code', 'index']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for product in products:
                writer.writerow(product)
                
        print(f"Exported {len(products)} {category} products to {filename}")

# Export uncategorized products
if uncategorized:
    filename = os.path.join(output_dir, "uncategorized_products.csv")
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['name', 'tariff_code', 'index']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for product in uncategorized:
            writer.writerow(product)
            
    print(f"Exported {len(uncategorized)} uncategorized products to {filename}")

# Categorize by tariff code prefix
tariff_categories = {}
for row in data_rows:
    product_name, tariff_code, index = row
    if tariff_code and isinstance(tariff_code, (int, float)):
        prefix = str(int(tariff_code))[:2]
        if prefix not in tariff_categories:
            tariff_categories[prefix] = []
        tariff_categories[prefix].append({
            'name': product_name,
            'tariff_code': tariff_code,
            'index': index
        })

# Export tariff-based categories
for prefix, products in tariff_categories.items():
    if products:
        filename = os.path.join(output_dir, f"tariff_{prefix}_products.csv")
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['name', 'tariff_code', 'index']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for product in products:
                writer.writerow(product)
                
        print(f"Exported {len(products)} products with tariff prefix {prefix} to {filename}")

print("\nExport complete. Files saved in the 'categorized_products' directory.") 