import jdatetime
from django.utils import timezone
from datetime import datetime

def gregorian_to_jalali(date_obj):
    """تبدیل تاریخ میلادی به شمسی"""
    if not date_obj:
        return ""
    
    if isinstance(date_obj, str):
        try:
            date_obj = datetime.strptime(date_obj, '%Y-%m-%d').date()
        except ValueError:
            return date_obj
    
    # اگر تاریخ timezone دارد، آن را timezone-naive کنیم
    if hasattr(date_obj, 'tzinfo') and date_obj.tzinfo is not None:
        date_obj = date_obj.replace(tzinfo=None)
    
    try:
        j_date = jdatetime.date.fromgregorian(date=date_obj)
        return j_date.strftime('%Y/%m/%d')
    except:
        # اگر تبدیل با مشکل مواجه شد، تاریخ اصلی را برگردانیم
        if hasattr(date_obj, 'strftime'):
            return date_obj.strftime('%Y/%m/%d')
        return str(date_obj)

def gregorian_to_jalali_datetime(datetime_obj):
    """تبدیل تاریخ و زمان میلادی به شمسی"""
    if not datetime_obj:
        return ""
    
    # اگر datetime timezone دارد، آن را timezone-naive کنیم
    if hasattr(datetime_obj, 'tzinfo') and datetime_obj.tzinfo is not None:
        datetime_obj = datetime_obj.replace(tzinfo=None)
    
    try:
        j_datetime = jdatetime.datetime.fromgregorian(datetime=datetime_obj)
        return j_datetime.strftime('%Y/%m/%d %H:%M')
    except:
        # اگر تبدیل با مشکل مواجه شد، تاریخ اصلی را برگردانیم
        if hasattr(datetime_obj, 'strftime'):
            return datetime_obj.strftime('%Y-%m-%d %H:%M')
        return str(datetime_obj)

def jalali_to_gregorian(jalali_date_str):
    """تبدیل تاریخ شمسی به میلادی
    ورودی باید در فرمت YYYY/MM/DD یا YYYY-MM-DD باشد
    """
    if not jalali_date_str:
        return None
    
    try:
        # پشتیبانی از هر دو فرمت / و -
        if '/' in jalali_date_str:
            jalali_year, jalali_month, jalali_day = map(int, jalali_date_str.split('/'))
        elif '-' in jalali_date_str:
            jalali_year, jalali_month, jalali_day = map(int, jalali_date_str.split('-'))
        else:
            return None
            
        j_date = jdatetime.date(jalali_year, jalali_month, jalali_day)
        g_date = j_date.togregorian()
        
        return g_date
    except:
        return None
    
def get_persian_month_name(month_number):
    """دریافت نام ماه شمسی بر اساس شماره ماه"""
    persian_months = {
        1: 'فروردین',
        2: 'اردیبهشت',
        3: 'خرداد',
        4: 'تیر',
        5: 'مرداد',
        6: 'شهریور',
        7: 'مهر',
        8: 'آبان',
        9: 'آذر',
        10: 'دی',
        11: 'بهمن',
        12: 'اسفند'
    }
    return persian_months.get(month_number, str(month_number))

def get_jalali_month_days(year, month):
    """محاسبه تعداد روزهای یک ماه شمسی مشخص"""
    if month <= 6:
        return 31
    elif month <= 11:
        return 30
    else:  # month == 12
        if jdatetime.date(year, month, 1).isleap():
            return 30
        else:
            return 29

def get_current_jalali_date():
    """دریافت تاریخ شمسی امروز"""
    now = timezone.now()
    j_date = jdatetime.date.fromgregorian(date=now.date())
    return j_date

def get_jalali_year_month():
    """دریافت سال و ماه شمسی کنونی"""
    j_date = get_current_jalali_date()
    return j_date.year, j_date.month 