from django import template

register = template.Library()

@register.filter
def percentage_of(value, total):
    """Calculate percentage of a value relative to a total"""
    try:
        return float(value) / float(total) * 100
    except (ValueError, ZeroDivisionError):
        return 0 