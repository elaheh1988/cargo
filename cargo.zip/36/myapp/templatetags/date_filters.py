from django import template
from myapp.date_utils import gregorian_to_jalali, gregorian_to_jalali_datetime

register = template.Library()

@register.filter(name='to_jalali')
def to_jalali(value):
    """تبدیل تاریخ میلادی به شمسی"""
    return gregorian_to_jalali(value)

@register.filter(name='to_jalali_datetime')
def to_jalali_datetime(value):
    """تبدیل تاریخ و زمان میلادی به شمسی"""
    return gregorian_to_jalali_datetime(value) 