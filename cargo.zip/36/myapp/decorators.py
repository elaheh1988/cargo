from functools import wraps
from django.shortcuts import redirect
from django.contrib import messages
from .models import UserProfile, UserRole

def role_required(roles):
    """
    Decorator to restrict access based on user role
    roles: list of allowed roles from UserRole enum
    """
    def decorator(view_func):
        @wraps(view_func)
        def wrapped(request, *args, **kwargs):
            if not request.user.is_authenticated:
                messages.error(request, 'برای دسترسی به این صفحه باید وارد شوید.')
                return redirect('login')
            
            try:
                user_profile = UserProfile.objects.get(user=request.user)
                if user_profile.role in roles:
                    return view_func(request, *args, **kwargs)
                else:
                    messages.error(request, 'شما دسترسی لازم برای مشاهده این صفحه را ندارید.')
                    return redirect('login')
            except UserProfile.DoesNotExist:
                messages.error(request, 'پروفایل کاربری یافت نشد.')
                return redirect('login')
            
        return wrapped
    return decorator

# Specific role decorators
def staff_required(view_func):
    return role_required([UserRole.STAFF])(view_func)

def assessor_required(view_func):
    return role_required([UserRole.ASSESSOR])(view_func)

def warehouse_required(view_func):
    return role_required([UserRole.WAREHOUSE])(view_func)

def manager_required(view_func):
    return role_required([UserRole.MANAGER])(view_func) 