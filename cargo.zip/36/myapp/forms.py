from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.utils import timezone
from datetime import timedelta
from .models import CustomerRequest, UserProfile, UserRole, Product

class CustomerRequestForm(forms.ModelForm):
    class Meta:
        model = CustomerRequest
        fields = [
            'first_name', 'last_name', 'national_id', 'father_name', 
            'phone_number', 'province', 'city', 'address', 'building_no', 
            'postal_code', 'passport_scan', 'product', 'quantity', 'shipping_cost',
            'receiver_name', 'receiver_phone', 'receiver_national_id', 'description'
        ]
        widgets = {
            'address': forms.Textarea(attrs={'rows': 3}),
            'description': forms.Textarea(attrs={'rows': 3, 'placeholder': 'در صورت نیاز به ذکر توضیحات، در این قسمت بنویسید.'}),
            'product': forms.Select(attrs={'class': 'form-select'}),
            'passport_scan': forms.FileInput(attrs={'class': 'form-control', 'id': 'passport_scan_input'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs['class'] = 'form-control'
            field.widget.attrs['dir'] = 'rtl'
        
        self.fields['product'].widget.attrs.update({
            'class': 'form-select',
            'data-bs-toggle': 'tooltip',
            'title': 'محصول مورد نظر را انتخاب کنید'
        })
        
        self.fields['product'].label = 'انتخاب محصول'
        self.fields['quantity'].label = 'تعداد / مقدار'
        self.fields['shipping_cost'].label = 'هزینه حمل و نقل'
        self.fields['receiver_name'].label = 'نام تحویل گیرنده'
        self.fields['receiver_phone'].label = 'شماره تماس تحویل گیرنده'
        self.fields['receiver_national_id'].label = 'کد ملی تحویل گیرنده'
        self.fields['description'].label = 'توضیحات متقاضی'

    def clean_national_id(self):
        national_id = self.cleaned_data.get('national_id')
        
        # تعیین بازه زمانی یک سال گذشته
        one_year_ago = timezone.now() - timedelta(days=365)
        
        # بررسی وجود کد ملی در یک سال گذشته
        if CustomerRequest.objects.filter(
            national_id=national_id,
            created_at__gte=one_year_ago
        ).exists():
            raise forms.ValidationError(
                "این کد ملی قبلاً در سیستم ثبت شده است. هر کد ملی فقط یکبار در سال اجازه ثبت درخواست دارد."
            )
        
        # اگر کد ملی معتبر بود یا تکراری نبود، مقدار را برمی‌گردانیم
        return national_id

class AssessmentForm(forms.ModelForm):
    assessment_notes = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
        required=False,
        label='یادداشت‌های داخلی'
    )
    
    additional_documents = forms.FileField(
        widget=forms.FileInput(attrs={'class': 'form-control'}),
        required=False,
        label='بارگذاری مستندات تکمیلی'
    )
    
    assessment_checklist = forms.MultipleChoiceField(
        widget=forms.CheckboxSelectMultiple(),
        required=True,
        label='لیست بررسی',
        choices=[
            ('address_verified', 'آدرس و کد پستی بررسی شد'),
            ('identity_verified', 'اطلاعات هویتی بررسی شد'),
            ('quantity_approved', 'مقدار کالا مورد تایید است'),
            ('shipping_verified', 'هزینه حمل و نقل بررسی شد')
        ],
        error_messages={
            'required': 'لطفاً تمام موارد لیست بررسی را تیک بزنید'
        }
    )
    
    request_additional_info = forms.BooleanField(
        required=False,
        label='درخواست اطلاعات تکمیلی'
    )
    
    additional_info_message = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
        required=False,
        label='پیام درخواست اطلاعات تکمیلی'
    )
    
    class Meta:
        model = CustomerRequest
        fields = ['status', 'rejection_reason']
        widgets = {
            'rejection_reason': forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
            'status': forms.Select(attrs={'class': 'form-control'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Limit status choices to only approved or rejected
        self.fields['status'].choices = [
            ('APPROVED', 'تایید شده'),
            ('REJECTED', 'رد شده')
        ]
        
        # اضافه کردن کلاس به چک‌باکس‌ها - روش جدید برای دسترسی به ویجت‌ها
        # این روش با Django 5.2 سازگار است
        self.fields['assessment_checklist'].widget.attrs['class'] = 'form-check-input'
    
    def clean(self):
        cleaned_data = super().clean()
        checklist = cleaned_data.get('assessment_checklist', [])
        required_checks = [choice[0] for choice in self.fields['assessment_checklist'].choices]
        
        # بررسی اینکه آیا تمام گزینه‌های لازم تیک زده شده‌اند
        if not all(check in checklist for check in required_checks):
            self.add_error('assessment_checklist', 'لطفاً تمام موارد لیست بررسی را تیک بزنید')
        
        return cleaned_data

class DeliveryForm(forms.ModelForm):
    class Meta:
        model = CustomerRequest
        fields = ['tracking_code', 'receiver_name', 'receiver_phone', 'receiver_national_id']
        widgets = {
            'tracking_code': forms.TextInput(attrs={'class': 'form-control', 'dir': 'rtl', 'placeholder': '99/999999999999'}),
            'receiver_name': forms.TextInput(attrs={'class': 'form-control', 'dir': 'rtl'}),
            'receiver_phone': forms.TextInput(attrs={'class': 'form-control', 'dir': 'rtl'}),
            'receiver_national_id': forms.TextInput(attrs={'class': 'form-control', 'dir': 'rtl'})
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['tracking_code'].label = 'کد پیگیری'
        self.fields['receiver_name'].label = 'نام تحویل گیرنده'
        self.fields['receiver_phone'].label = 'شماره تماس تحویل گیرنده'
        self.fields['receiver_national_id'].label = 'کد ملی تحویل گیرنده'
        
        # Make receiver information required for delivery
        self.fields['receiver_name'].required = True
        self.fields['receiver_phone'].required = True
        
    def clean_tracking_code(self):
        tracking_code = self.cleaned_data.get('tracking_code')
        
        # بررسی فرمت صحیح کد پیگیری (99/999999999999)
        import re
        if not re.match(r'^\d{2}/\d{12}$', tracking_code):
            raise forms.ValidationError('فرمت کد پیگیری باید به صورت 99/999999999999 باشد.')
        
        # بررسی عدم تکراری بودن کد پیگیری
        if CustomerRequest.objects.filter(tracking_code=tracking_code).exclude(id=self.instance.id).exists():
            raise forms.ValidationError('این کد پیگیری قبلاً استفاده شده است.')
        
        return tracking_code

class UserCreateForm(UserCreationForm):
    role = forms.ChoiceField(choices=UserRole.choices, widget=forms.Select(attrs={'class': 'form-control'}))
    
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control', 'dir': 'rtl'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control', 'dir': 'rtl'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs['class'] = 'form-control'
        self.fields['password2'].widget.attrs['class'] = 'form-control'
        
    def save(self, commit=True):
        user = super().save(commit=commit)
        if commit:
            UserProfile.objects.create(
                user=user,
                role=self.cleaned_data['role']
            )
        return user 