from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from myapp.models import UserProfile, UserRole

class Command(BaseCommand):
    help = 'Creates default users with different roles'

    def handle(self, *args, **options):
        self.stdout.write('Creating default users...')
        
        # Create manager user
        manager, created = User.objects.get_or_create(
            username='manager',
            defaults={
                'first_name': 'مدیر',
                'last_name': 'سیستم',
                'email': 'manager@example.com',
                'is_staff': True,
            }
        )
        
        if created:
            manager.set_password('manager123')
            manager.save()
            UserProfile.objects.create(user=manager, role=UserRole.MANAGER)
            self.stdout.write(self.style.SUCCESS(f'Manager user created: {manager.username}'))
        else:
            self.stdout.write(f'Manager user already exists: {manager.username}')
        
        # Create staff user
        staff, created = User.objects.get_or_create(
            username='staff',
            defaults={
                'first_name': 'کارمند',
                'last_name': 'شرکت',
                'email': 'staff@example.com',
            }
        )
        
        if created:
            staff.set_password('staff123')
            staff.save()
            UserProfile.objects.create(user=staff, role=UserRole.STAFF)
            self.stdout.write(self.style.SUCCESS(f'Staff user created: {staff.username}'))
        else:
            self.stdout.write(f'Staff user already exists: {staff.username}')
        
        # Create assessor user
        assessor, created = User.objects.get_or_create(
            username='assessor',
            defaults={
                'first_name': 'ارزیاب',
                'last_name': 'درخواست',
                'email': 'assessor@example.com',
            }
        )
        
        if created:
            assessor.set_password('assessor123')
            assessor.save()
            UserProfile.objects.create(user=assessor, role=UserRole.ASSESSOR)
            self.stdout.write(self.style.SUCCESS(f'Assessor user created: {assessor.username}'))
        else:
            self.stdout.write(f'Assessor user already exists: {assessor.username}')
        
        # Create warehouse user
        warehouse, created = User.objects.get_or_create(
            username='warehouse',
            defaults={
                'first_name': 'انباردار',
                'last_name': 'سیستم',
                'email': 'warehouse@example.com',
            }
        )
        
        if created:
            warehouse.set_password('warehouse123')
            warehouse.save()
            UserProfile.objects.create(user=warehouse, role=UserRole.WAREHOUSE)
            self.stdout.write(self.style.SUCCESS(f'Warehouse user created: {warehouse.username}'))
        else:
            self.stdout.write(f'Warehouse user already exists: {warehouse.username}')
        
        self.stdout.write(self.style.SUCCESS('All default users created successfully!')) 