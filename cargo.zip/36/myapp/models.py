from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Product(models.Model):
    name = models.CharField(max_length=200)
    tariff = models.DecimalField(max_digits=10, decimal_places=2)
    
    def __str__(self):
        return self.name

class RequestStatus(models.TextChoices):
    PENDING = 'PENDING', 'در انتظار بررسی'
    APPROVED = 'APPROVED', 'تایید شده'
    REJECTED = 'REJECTED', 'رد شده'
    DELIVERED = 'DELIVERED', 'تحویل داده شده'

class CustomerRequest(models.Model):
    first_name = models.CharField(max_length=100, verbose_name="نام")
    last_name = models.CharField(max_length=100, verbose_name="نام خانوادگی")
    national_id = models.CharField(max_length=10, verbose_name="کد ملی")
    father_name = models.CharField(max_length=100, verbose_name="نام پدر")
    phone_number = models.CharField(max_length=11, verbose_name="شماره تماس")
    province = models.CharField(max_length=100, verbose_name="استان")
    city = models.CharField(max_length=100, verbose_name="شهر")
    address = models.TextField(verbose_name="آدرس")
    building_no = models.CharField(max_length=20, verbose_name="پلاک")
    postal_code = models.CharField(max_length=10, verbose_name="کد پستی")
    
    passport_scan = models.ImageField(upload_to='passport_scans/', blank=True, null=True, verbose_name="اسکن پاسپورت")
    
    product = models.ForeignKey(Product, on_delete=models.PROTECT, verbose_name="محصول")
    quantity = models.PositiveIntegerField(verbose_name="تعداد/وزن")
    shipping_cost = models.DecimalField(max_digits=12, decimal_places=2, verbose_name="هزینه حمل و نقل")
    
    receiver_name = models.CharField(max_length=100, blank=True, null=True, verbose_name="نام تحویل گیرنده")
    receiver_phone = models.CharField(max_length=11, blank=True, null=True, verbose_name="شماره تماس تحویل گیرنده")
    receiver_national_id = models.CharField(max_length=10, blank=True, null=True, verbose_name="کد ملی تحویل گیرنده")
    
    description = models.TextField(blank=True, null=True, verbose_name="توضیحات متقاضی")
    
    status = models.CharField(max_length=20, choices=RequestStatus.choices, default=RequestStatus.PENDING, verbose_name="وضعیت")
    rejection_reason = models.TextField(blank=True, null=True, verbose_name="دلیل رد درخواست")
    tracking_code = models.CharField(max_length=30, blank=True, null=True, verbose_name="کد پیگیری")
    
    unique_code = models.CharField(max_length=10, unique=True, verbose_name="کد یکتا")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ثبت")
    
    # Staff member who handled this request (optional)
    assessor = models.ForeignKey(
        User, on_delete=models.SET_NULL, 
        null=True, blank=True, 
        related_name='assessed_requests',
        verbose_name="ارزیاب"
    )
    
    warehouse_keeper = models.ForeignKey(
        User, on_delete=models.SET_NULL, 
        null=True, blank=True, 
        related_name='warehoused_requests',
        verbose_name="انباردار"
    )
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.product.name}"
    
    class Meta:
        verbose_name = "درخواست"
        verbose_name_plural = "درخواست‌ها"
        indexes = [
            models.Index(fields=['national_id']),
            models.Index(fields=['status']),
            models.Index(fields=['created_at']),
        ]

class UserRole(models.TextChoices):
    STAFF = 'STAFF', 'کارمند'
    ASSESSOR = 'ASSESSOR', 'ارزیاب'
    WAREHOUSE = 'WAREHOUSE', 'انباردار'
    MANAGER = 'MANAGER', 'مدیر'

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(
        max_length=20,
        choices=UserRole.choices,
        default=UserRole.STAFF,
        verbose_name='نقش'
    )
    
    def __str__(self):
        return f"{self.user.username} - {self.get_role_display()}"
