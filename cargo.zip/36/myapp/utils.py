import uuid
import os
import csv
from django.conf import settings
from .models import Product

def generate_unique_code():
    """Generate a unique code for customer requests"""
    return str(uuid.uuid4().hex)[:10].upper()

def import_products_from_excel():
    """
    Import products from CSV file in the project folder.
    If CSV file exists, read it and import products.
    If not, create default products.
    """
    csv_path = os.path.join(settings.BASE_DIR, 'products.csv')
    print(f"بررسی وجود فایل CSV در مسیر {csv_path}")
    
    try:
        # اگر فایل CSV وجود داشت، از آن بخواند
        if os.path.exists(csv_path):
            try:
                # خواندن فایل CSV
                print("فایل CSV یافت شد. در حال خواندن فایل...")
                products_added = 0
                
                with open(csv_path, 'r', encoding='utf-8-sig') as csvfile:
                    # سعی می‌کنیم با استفاده از DictReader فایل را بخوانیم
                    try:
                        reader = csv.DictReader(csvfile)
                        rows = list(reader)
                        
                        # اگر هیچ ردیفی نداشت یا هدرها درست نبودند
                        if not rows or not any(['name' in row or 'نام' in row or 'محصول' in row for row in rows]):
                            # دوباره فایل را باز می‌کنیم و به صورت ساده می‌خوانیم
                            csvfile.seek(0)
                            reader = csv.reader(csvfile)
                            header = next(reader, None)
                            
                            # اگر هدر وجود داشت
                            if header and len(header) >= 2:
                                for row in reader:
                                    if len(row) >= 2:
                                        name = row[0].strip()
                                        tariff_str = row[1].strip()
                                        
                                        # تبدیل تعرفه به عدد
                                        try:
                                            tariff = float(tariff_str.replace(',', ''))
                                        except (ValueError, AttributeError):
                                            print(f"خطا در تبدیل تعرفه برای محصول '{name}': {tariff_str}")
                                            tariff = 0
                                            
                                        # اگر محصول قبلاً وجود ندارد، آن را اضافه کن
                                        if name and not Product.objects.filter(name=name).exists():
                                            Product.objects.create(name=name, tariff=tariff)
                                            products_added += 1
                                            print(f"محصول '{name}' با تعرفه {tariff} اضافه شد.")
                                        elif name:
                                            print(f"محصول '{name}' قبلاً در پایگاه داده وجود دارد.")
                        else:
                            # استفاده از DictReader
                            for row in rows:
                                # بررسی وجود ستون‌های مورد نیاز
                                name = row.get('name') or row.get('نام') or row.get('محصول')
                                tariff = row.get('tariff') or row.get('تعرفه') or row.get('قیمت')
                                
                                # اگر نام و تعرفه وجود داشتند، محصول را ایجاد کن
                                if name and tariff:
                                    # تبدیل تعرفه به عدد
                                    try:
                                        tariff = float(str(tariff).replace(',', ''))
                                    except (ValueError, AttributeError):
                                        # اگر تبدیل با خطا مواجه شد، از مقدار پیش‌فرض استفاده کن
                                        print(f"خطا در تبدیل تعرفه برای محصول '{name}': {tariff}")
                                        tariff = 0
                                        
                                    # اگر محصول قبلاً وجود ندارد، آن را اضافه کن
                                    if not Product.objects.filter(name=name).exists():
                                        Product.objects.create(name=name, tariff=tariff)
                                        products_added += 1
                                        print(f"محصول '{name}' با تعرفه {tariff} اضافه شد.")
                                    else:
                                        print(f"محصول '{name}' قبلاً در پایگاه داده وجود دارد.")
                    
                    except Exception as e:
                        print(f"خطا در خواندن فایل CSV با DictReader: {e}")
                        csvfile.seek(0)
                        reader = csv.reader(csvfile)
                        next(reader, None)  # Skip header
                        
                        for row in reader:
                            if len(row) >= 2:
                                name = row[0].strip()
                                tariff_str = row[1].strip()
                                
                                # تبدیل تعرفه به عدد
                                try:
                                    tariff = float(tariff_str.replace(',', ''))
                                except (ValueError, AttributeError):
                                    print(f"خطا در تبدیل تعرفه برای محصول '{name}': {tariff_str}")
                                    tariff = 0
                                    
                                # اگر محصول قبلاً وجود ندارد، آن را اضافه کن
                                if name and not Product.objects.filter(name=name).exists():
                                    Product.objects.create(name=name, tariff=tariff)
                                    products_added += 1
                                    print(f"محصول '{name}' با تعرفه {tariff} اضافه شد.")
                                elif name:
                                    print(f"محصول '{name}' قبلاً در پایگاه داده وجود دارد.")
                
                # اگر حداقل یک محصول اضافه شد، موفقیت را برگردان
                if products_added > 0:
                    print(f"تعداد {products_added} محصول از فایل CSV به پایگاه داده اضافه شد.")
                    return True
                else:
                    print("هیچ محصول جدیدی از فایل CSV اضافه نشد.")
                    
            except Exception as e:
                print(f"خطا در هنگام واردکردن محصولات از فایل CSV: {e}")
        else:
            print(f"فایل CSV در مسیر {csv_path} یافت نشد.")
        
        # اگر فایل CSV وجود نداشت یا مشکلی در خواندن آن بود، محصولات پیش‌فرض را ایجاد کن
        if Product.objects.count() == 0:
            print("هیچ محصولی در پایگاه داده یافت نشد. در حال ایجاد محصولات پیش‌فرض...")
            products = [
                {"name": "تلویزیون سامسونگ 55 اینچ", "tariff": 5000000},
                {"name": "یخچال ال جی", "tariff": 8000000},
                {"name": "ماشین لباسشویی بوش", "tariff": 6500000},
                {"name": "کولر گازی اسپلیت", "tariff": 4500000},
                {"name": "اجاق گاز فردار", "tariff": 3000000},
                {"name": "جاروبرقی", "tariff": 1500000},
                {"name": "مایکروویو", "tariff": 2000000},
                {"name": "ماشین ظرفشویی", "tariff": 7000000},
                {"name": "پنکه سقفی", "tariff": 800000},
                {"name": "پلوپز", "tariff": 600000},
            ]
            
            for product_data in products:
                Product.objects.create(
                    name=product_data["name"],
                    tariff=product_data["tariff"]
                )
            
            print(f"تعداد {len(products)} محصول پیش‌فرض در پایگاه داده ایجاد شد.")
            return True
    
    except Exception as e:
        print(f"خطای کلی در فرآیند ورود اطلاعات: {e}")
    
    return False 