from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView, LogoutView
from django.http import JsonResponse, HttpResponse
from django.urls import reverse_lazy
from django.contrib import messages
from django.contrib.auth.models import User
from django.utils import timezone
from django.core.paginator import Paginator
from django.db.models import Count, Q
from datetime import timedelta, datetime
import json

from .models import CustomerRequest, Product, UserProfile, RequestStatus, UserRole
from .forms import CustomerRequestForm, AssessmentForm, DeliveryForm, UserCreateForm
from .decorators import staff_required, assessor_required, warehouse_required, manager_required
from .utils import generate_unique_code, import_products_from_excel
from .date_utils import gregorian_to_jalali, gregorian_to_jalali_datetime, jalali_to_gregorian

class CustomLoginView(LoginView):
    template_name = 'myapp/login.html'
    redirect_authenticated_user = True
    
    def get_success_url(self):
        # Check if there's a next parameter in the request
        next_url = self.request.GET.get('next')
        if next_url:
            return next_url
            
        # Otherwise redirect based on role
        user_role = UserRole.STAFF  # Default role
        try:
            user_profile = UserProfile.objects.get(user=self.request.user)
            user_role = user_profile.role
        except UserProfile.DoesNotExist:
            # Create a default profile if not exists
            UserProfile.objects.create(user=self.request.user, role=UserRole.STAFF)
        
        # Redirect based on role
        if user_role == UserRole.STAFF:
            return reverse_lazy('customer_request')
        elif user_role == UserRole.ASSESSOR:
            return reverse_lazy('assessment_list')
        elif user_role == UserRole.WAREHOUSE:
            return reverse_lazy('warehouse_list')
        elif user_role == UserRole.MANAGER:
            return reverse_lazy('dashboard')
        return reverse_lazy('index')
        
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['next'] = self.request.GET.get('next', '')
        return context

def index(request):
    if request.user.is_authenticated:
        try:
            user_profile = UserProfile.objects.get(user=request.user)
            role = user_profile.role
            
            if role == UserRole.STAFF:
                return redirect('customer_request')
            elif role == UserRole.ASSESSOR:
                return redirect('assessment_list')
            elif role == UserRole.WAREHOUSE:
                return redirect('warehouse_list')
            elif role == UserRole.MANAGER:
                return redirect('dashboard')
        except UserProfile.DoesNotExist:
            pass
    
    return redirect('login')

def logout_view(request):
    """Custom logout view to ensure proper redirection"""
    from django.contrib.auth import logout
    if request.method == 'POST':
        logout(request)
        return redirect('login')
    else:
        # Show a confirmation page for GET requests
        return render(request, 'myapp/logout_confirm.html')

@login_required
@staff_required
def customer_request(request):
    receipt = None
    
    # وارد کردن محصولات از فایل اکسل در هر بار لود صفحه
    # این عملیات تنها محصولاتی را که قبلاً وجود ندارند اضافه می‌کند
    import_products_from_excel()
    
    if request.method == 'POST':
        form = CustomerRequestForm(request.POST, request.FILES)
        if form.is_valid():
            # Create request but don't save yet
            customer_request = form.save(commit=False)
            customer_request.unique_code = generate_unique_code()
            
            # پردازش فایل پاسپورت اسکن شده
            if 'passport_scan' in request.FILES:
                customer_request.passport_scan = request.FILES['passport_scan']
                
            customer_request.save()
            
            # Set receipt for showing
            receipt = customer_request
            
            # Create a new form for next entry
            form = CustomerRequestForm()
            
            messages.success(request, 'درخواست با موفقیت ثبت شد.')
        else:
            # اگر فرم نامعتبر بود، نمایش پیام‌های خطا
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{error}")
    else:
        form = CustomerRequestForm()
    
    return render(request, 'myapp/customer_request.html', {
        'form': form,
        'receipt': receipt
    })

@login_required
def get_product_tariff(request):
    """AJAX endpoint to get product tariff"""
    product_id = request.GET.get('product_id')
    tariff = 0
    
    if product_id:
        try:
            product = Product.objects.get(pk=product_id)
            tariff = product.tariff
        except Product.DoesNotExist:
            pass
    
    return JsonResponse({'tariff': tariff})

@login_required
@assessor_required
def assessment_list(request):
    # ابتدا آمارها را محاسبه می‌کنیم
    total_pending = CustomerRequest.objects.filter(status=RequestStatus.PENDING).count()
    reviewed_by_me = CustomerRequest.objects.filter(assessor=request.user).count()
    approved_by_me = CustomerRequest.objects.filter(assessor=request.user, status=RequestStatus.APPROVED).count()
    rejected_by_me = CustomerRequest.objects.filter(assessor=request.user, status=RequestStatus.REJECTED).count()
    
    # نمودار عملکرد ارزیاب در هفته اخیر
    today = timezone.now().date()
    week_ago = today - timedelta(days=7)
    weekly_stats = {}
    
    # Initialize all days with zero count
    for i in range(7):
        day = week_ago + timedelta(days=i+1)
        weekly_stats[day.strftime('%Y-%m-%d')] = {'approved': 0, 'rejected': 0}
    
    # Get actual counts for assessor's performance
    assessments_in_week = CustomerRequest.objects.filter(
        assessor=request.user,
        status__in=[RequestStatus.APPROVED, RequestStatus.REJECTED],
        created_at__date__gt=week_ago, 
        created_at__date__lte=today
    )
    
    for req in assessments_in_week:
        day_str = req.created_at.strftime('%Y-%m-%d')
        if day_str in weekly_stats:
            if req.status == RequestStatus.APPROVED:
                weekly_stats[day_str]['approved'] += 1
            elif req.status == RequestStatus.REJECTED:
                weekly_stats[day_str]['rejected'] += 1
    
    # Prepare data for charts
    weekly_labels = []
    weekly_approved = []
    weekly_rejected = []
    
    for day, counts in weekly_stats.items():
        date_obj = datetime.strptime(day, '%Y-%m-%d')
        weekly_labels.append(date_obj.strftime('%m/%d'))
        weekly_approved.append(counts['approved'])
        weekly_rejected.append(counts['rejected'])
    
    # فیلترینگ و جستجو
    search_query = request.GET.get('search', '')
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')
    sort_by = request.GET.get('sort_by', '-created_at')
    
    # پایه کوئری
    requests_list = CustomerRequest.objects.filter(status=RequestStatus.PENDING)
    
    # اعمال فیلترها
    if search_query:
        requests_list = requests_list.filter(
            Q(first_name__icontains=search_query) | 
            Q(last_name__icontains=search_query) | 
            Q(national_id__icontains=search_query) | 
            Q(unique_code__icontains=search_query) |
            Q(product__name__icontains=search_query)
        )
    
    # فیلتر تاریخ
    if date_from:
        try:
            # بررسی اینکه آیا تاریخ میلادی است یا شمسی
            if '/' in date_from:  # فرمت شمسی
                gregorian_date = jalali_to_gregorian(date_from)
                if gregorian_date:
                    requests_list = requests_list.filter(created_at__date__gte=gregorian_date)
            else:  # فرض میلادی
                date_from_obj = datetime.strptime(date_from, '%Y-%m-%d').date()
                requests_list = requests_list.filter(created_at__date__gte=date_from_obj)
        except ValueError:
            date_from = None
    
    if date_to:
        try:
            # بررسی اینکه آیا تاریخ میلادی است یا شمسی
            if '/' in date_to:  # فرمت شمسی
                gregorian_date = jalali_to_gregorian(date_to)
                if gregorian_date:
                    requests_list = requests_list.filter(created_at__date__lte=gregorian_date)
            else:  # فرض میلادی
                date_to_obj = datetime.strptime(date_to, '%Y-%m-%d').date()
                requests_list = requests_list.filter(created_at__date__lte=date_to_obj)
        except ValueError:
            date_to = None
    
    # مرتب‌سازی
    valid_sort_fields = ['created_at', '-created_at', 'first_name', '-first_name', 'product__name', '-product__name']
    if sort_by in valid_sort_fields:
        requests_list = requests_list.order_by(sort_by)
    else:
        requests_list = requests_list.order_by('-created_at')
    
    # Pagination
    paginator = Paginator(requests_list, 10)  # 10 items per page
    page = request.GET.get('page')
    requests = paginator.get_page(page)
    
    return render(request, 'myapp/assessment_list.html', {
        'requests': requests,
        'stats': {
            'total_pending': total_pending,
            'reviewed_by_me': reviewed_by_me,
            'approved_by_me': approved_by_me,
            'rejected_by_me': rejected_by_me,
        },
        'weekly_labels': json.dumps(weekly_labels),
        'weekly_approved': json.dumps(weekly_approved),
        'weekly_rejected': json.dumps(weekly_rejected),
        'filters': {
            'search': search_query,
            'date_from': date_from,
            'date_to': date_to,
            'sort_by': sort_by,
        }
    })

@login_required
@assessor_required
def assessment_detail(request, request_id):
    request_obj = get_object_or_404(CustomerRequest, id=request_id)
    
    # Check if request is already processed
    if request_obj.status != RequestStatus.PENDING:
        messages.error(request, 'این درخواست قبلاً ارزیابی شده است.')
        return redirect('assessment_list')
    
    if request.method == 'POST':
        form = AssessmentForm(request.POST, instance=request_obj)
        if form.is_valid():
            assessment = form.save(commit=False)
            
            # Set assessor
            assessment.assessor = request.user
            
            # Check if rejection reason is provided for rejected requests
            if assessment.status == RequestStatus.REJECTED and not assessment.rejection_reason:
                form.add_error('rejection_reason', 'برای رد درخواست، باید دلیل آن را بنویسید.')
                return render(request, 'myapp/assessment_detail.html', {
                    'form': form,
                    'request_obj': request_obj
                })
            
            # Check if all required checklist items are checked
            checklist = request.POST.getlist('assessment_checklist')
            required_checks = [choice[0] for choice in form.fields['assessment_checklist'].choices]
            
            if not all(check in checklist for check in required_checks):
                form.add_error('assessment_checklist', 'لطفاً تمام موارد لیست بررسی را تیک بزنید.')
                return render(request, 'myapp/assessment_detail.html', {
                    'form': form,
                    'request_obj': request_obj
                })
            
            assessment.save()
            messages.success(request, 'ارزیابی با موفقیت ثبت شد.')
            return redirect('assessment_list')
    else:
        form = AssessmentForm(instance=request_obj)
    
    return render(request, 'myapp/assessment_detail.html', {
        'form': form,
        'request_obj': request_obj
    })

@login_required
@assessor_required
def assessment_preview(request, request_id):
    """پیش‌نمایش درخواست برای ارزیابی"""
    request_obj = get_object_or_404(CustomerRequest, id=request_id)
    
    return render(request, 'myapp/assessment_preview.html', {
        'request_obj': request_obj
    })

@login_required
@warehouse_required
def warehouse_list(request):
    search_query = request.GET.get('search', '')
    city_filter = request.GET.get('city', '')
    product_filter = request.GET.get('product', '')
    sort_by = request.GET.get('sort', '-created_at')
    
    # Base queryset - Get all approved requests
    requests_list = CustomerRequest.objects.filter(status=RequestStatus.APPROVED)
    
    # Apply filters
    if search_query:
        requests_list = requests_list.filter(
            Q(first_name__icontains=search_query) | 
            Q(last_name__icontains=search_query) | 
            Q(national_id__icontains=search_query) | 
            Q(unique_code__icontains=search_query) |
            Q(product__name__icontains=search_query)
        )
    
    if city_filter:
        requests_list = requests_list.filter(city=city_filter)
        
    if product_filter:
        requests_list = requests_list.filter(product_id=product_filter)
    
    # Get stats for dashboard
    pending_count = requests_list.count()
    delivered_count = CustomerRequest.objects.filter(status=RequestStatus.DELIVERED, warehouse_keeper=request.user).count()
    
    # Get unique cities and their counts
    cities = CustomerRequest.objects.filter(status=RequestStatus.APPROVED).values_list('city', flat=True).distinct()
    city_stats = {}
    for city in cities:
        city_stats[city] = CustomerRequest.objects.filter(status=RequestStatus.APPROVED, city=city).count()
    
    # Get available products
    products = Product.objects.all()
    
    # Calculate average delivery time (in hours)
    delivered_requests = CustomerRequest.objects.filter(
        status=RequestStatus.DELIVERED, 
        warehouse_keeper=request.user
    )
    city_count = CustomerRequest.objects.filter(
        status__in=[RequestStatus.APPROVED, RequestStatus.DELIVERED]
    ).values('city').distinct().count()
    
    # Default value for average delivery time
    avg_delivery_time = 0
    
    # Apply sorting
    valid_sort_fields = ['created_at', '-created_at', 'quantity', '-quantity']
    if sort_by in valid_sort_fields:
        requests_list = requests_list.order_by(sort_by)
    else:
        requests_list = requests_list.order_by('-created_at')
    
    # Pagination
    paginator = Paginator(requests_list, 10)  # 10 items per page
    page = request.GET.get('page')
    requests = paginator.get_page(page)
    
    # Total requests for percentage calculation
    total_requests = CustomerRequest.objects.filter(status=RequestStatus.APPROVED).count()
    
    return render(request, 'myapp/warehouse_list.html', {
        'requests': requests,
        'pending_count': pending_count,
        'delivered_count': delivered_count,
        'avg_delivery_time': round(avg_delivery_time, 1),
        'city_count': city_count,
        'city_stats': city_stats,
        'cities': cities,
        'products': products,
        'total_requests': total_requests
    })

@login_required
@warehouse_required
def warehouse_reports(request):
    """گزارش‌گیری عملکرد انباردار"""
    # تاریخ‌های فیلتر
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')
    
    # آمارهای کلی
    total_handled = CustomerRequest.objects.filter(
        warehouse_keeper=request.user,
        status=RequestStatus.DELIVERED
    ).count()
    
    # کوئری پایه برای درخواست‌های تحویل شده
    delivered_requests = CustomerRequest.objects.filter(
        warehouse_keeper=request.user,
        status=RequestStatus.DELIVERED
    )
    
    # اگر فیلتر تاریخ داریم، اعمال می‌کنیم
    if date_from:
        try:
            date_from_obj = datetime.strptime(date_from, '%Y-%m-%d').date()
            delivered_requests = delivered_requests.filter(created_at__date__gte=date_from_obj)
        except ValueError:
            pass
    
    if date_to:
        try:
            date_to_obj = datetime.strptime(date_to, '%Y-%m-%d').date()
            delivered_requests = delivered_requests.filter(created_at__date__lte=date_to_obj)
        except ValueError:
            pass
    
    # آمار شهرها
    cities_count = delivered_requests.values('city').distinct().count()
    city_data = {}
    for city in delivered_requests.values('city').distinct():
        city_name = city['city']
        city_data[city_name] = delivered_requests.filter(city=city_name).count()
    
    # آمار زمان تحویل
    # در اینجا از created_at استفاده می‌کنیم چون فیلد modified_at موجود نیست
    # در یک سیستم واقعی باید از زمان تحویل واقعی استفاده شود
    min_delivery_time = 0
    max_delivery_time = 0
    avg_delivery_time = 0
    
    # میانگین تحویل روزانه (تعداد کالاهای تحویل شده تقسیم بر تعداد روزهای مختلف)
    if total_handled > 0:
        distinct_days = delivered_requests.dates('created_at', 'day').count()
        daily_average = round(total_handled / max(1, distinct_days), 1)
    else:
        daily_average = 0
    
    # نمودار آمار روزانه
    if date_from and date_to:
        try:
            date_from_obj = datetime.strptime(date_from, '%Y-%m-%d').date()
            date_to_obj = datetime.strptime(date_to, '%Y-%m-%d').date()
            
            # بازه زمانی برای نمودار
            date_range = [(date_from_obj + timedelta(days=x)) for x in range((date_to_obj - date_from_obj).days + 1)]
            
            date_labels = []
            daily_counts = []
            
            for day in date_range:
                date_labels.append(day.strftime('%Y-%m-%d'))
                count = delivered_requests.filter(created_at__date=day).count()
                daily_counts.append(count)
        except ValueError:
            date_labels = []
            daily_counts = []
    else:
        # آمار 7 روز اخیر
        today = timezone.now().date()
        week_ago = today - timedelta(days=7)
        date_range = [(week_ago + timedelta(days=x)) for x in range(8)]
        
        date_labels = []
        daily_counts = []
        
        for day in date_range:
            date_labels.append(day.strftime('%Y-%m-%d'))
            count = delivered_requests.filter(created_at__date=day).count()
            daily_counts.append(count)
    
    # آمار محصولات تحویل شده
    product_data = {}
    for request_obj in delivered_requests:
        product_name = request_obj.product.name
        if product_name in product_data:
            product_data[product_name] += 1
        else:
            product_data[product_name] = 1
    
    product_labels = list(product_data.keys())
    product_counts = list(product_data.values())
    
    # تهیه توزیع زمان تحویل
    time_distribution = [0, 0, 0, 0, 0]  # < 1h, 1-2h, 2-4h, 4-8h, > 8h
    time_labels = ["<1 ساعت", "1-2 ساعت", "2-4 ساعت", "4-8 ساعت", ">8 ساعت"]
    
    return render(request, 'myapp/warehouse_reports.html', {
        'total_handled': total_handled,
        'daily_average': daily_average,
        'cities_count': cities_count,
        'avg_delivery_time': round(avg_delivery_time, 1),
        'min_delivery_time': min_delivery_time,
        'max_delivery_time': max_delivery_time,
        'city_data': city_data,
        'date_labels': json.dumps(date_labels),
        'daily_counts': json.dumps(daily_counts),
        'product_labels': json.dumps(product_labels),
        'product_counts': json.dumps(product_counts),
        'time_labels': json.dumps(time_labels),
        'time_distribution': json.dumps(time_distribution),
        'filters': {
            'date_from': date_from,
            'date_to': date_to,
        }
    })

@login_required
@warehouse_required
def delivery_form(request, request_id):
    request_obj = get_object_or_404(CustomerRequest, id=request_id)
    delivered = False
    
    # Check if request is approved and not delivered
    if request_obj.status != RequestStatus.APPROVED:
        messages.error(request, 'این درخواست برای تحویل آماده نیست.')
        return redirect('warehouse_list')
    
    if request.method == 'POST':
        form = DeliveryForm(request.POST, instance=request_obj)
        unique_code_verify = request.POST.get('unique_code_verify', '')
        
        # Verify unique code
        if unique_code_verify != request_obj.unique_code:
            messages.error(request, 'کد یکتا وارد شده صحیح نیست.')
            return render(request, 'myapp/delivery_form.html', {
                'form': form,
                'request_obj': request_obj
            })
        
        if form.is_valid():
            if not form.cleaned_data['receiver_name']:
                form.add_error('receiver_name', 'وارد کردن نام تحویل گیرنده الزامی است.')
                return render(request, 'myapp/delivery_form.html', {
                    'form': form,
                    'request_obj': request_obj
                })
                
            if not form.cleaned_data['receiver_phone']:
                form.add_error('receiver_phone', 'وارد کردن شماره تماس تحویل گیرنده الزامی است.')
                return render(request, 'myapp/delivery_form.html', {
                    'form': form,
                    'request_obj': request_obj
                })
            
            delivery = form.save(commit=False)
            delivery.status = RequestStatus.DELIVERED
            delivery.warehouse_keeper = request.user
            delivery.save()
            
            delivered = True
            messages.success(request, 'تحویل کالا با موفقیت ثبت شد.')
        else:
            # اگر فرم شامل خطاهای دیگر باشد (مانند فرمت کد پیگیری)، پیام مناسب نمایش داده شود
            if 'tracking_code' in form.errors:
                messages.error(request, form.errors['tracking_code'][0])
    else:
        form = DeliveryForm(instance=request_obj)
    
    return render(request, 'myapp/delivery_form.html', {
        'form': form,
        'request_obj': request_obj,
        'delivered': delivered
    })

@login_required
@manager_required
def dashboard(request):
    # صریحاً برای دسترسی غیرمجاز بررسی کنید
    if not request.user.is_authenticated:
        return redirect('login')
    
    if not hasattr(request.user, 'userprofile') or request.user.userprofile.role != UserRole.MANAGER:
        messages.error(request, 'شما دسترسی به این صفحه را ندارید.')
        return redirect('index')
    
    # فیلترهای پیش‌فرض
    date_from = request.GET.get('start_date')
    date_to = request.GET.get('end_date')
    city_filter = request.GET.get('city', request.GET.get('province', ''))  # پشتیبانی از هر دو پارامتر province و city در URL
    status_filter = request.GET.get('status')
    search_query = request.GET.get('search')

    # پایه‌ی کوئری
    requests_query = CustomerRequest.objects.all()
    
    # اعمال فیلترها
    if date_from:
        try:
            # بررسی اینکه آیا تاریخ میلادی است یا شمسی
            if '/' in date_from:  # فرمت شمسی
                gregorian_date = jalali_to_gregorian(date_from)
                if gregorian_date:
                    requests_query = requests_query.filter(created_at__date__gte=gregorian_date)
            else:  # فرض میلادی
                date_from_obj = datetime.strptime(date_from, '%Y-%m-%d').date()
                requests_query = requests_query.filter(created_at__date__gte=date_from_obj)
        except ValueError:
            date_from = None
    
    if date_to:
        try:
            # بررسی اینکه آیا تاریخ میلادی است یا شمسی
            if '/' in date_to:  # فرمت شمسی
                gregorian_date = jalali_to_gregorian(date_to)
                if gregorian_date:
                    requests_query = requests_query.filter(created_at__date__lte=gregorian_date)
            else:  # فرض میلادی
                date_to_obj = datetime.strptime(date_to, '%Y-%m-%d').date()
                requests_query = requests_query.filter(created_at__date__lte=date_to_obj)
        except ValueError:
            date_to = None
    
    if city_filter:
        requests_query = requests_query.filter(city=city_filter)
    
    if status_filter:
        requests_query = requests_query.filter(status=status_filter)
    
    if search_query:
        requests_query = requests_query.filter(
            Q(first_name__icontains=search_query) | 
            Q(last_name__icontains=search_query) | 
            Q(national_id__icontains=search_query) | 
            Q(unique_code__icontains=search_query)
        )
    
    # شهرها برای فیلتر
    cities = CustomerRequest.objects.values_list('city', flat=True).distinct()
    
    # شمارش هر وضعیت
    total_requests = requests_query.count()
    pending_requests = requests_query.filter(status=RequestStatus.PENDING).count()
    approved_requests = requests_query.filter(status=RequestStatus.APPROVED).count()
    rejected_requests = requests_query.filter(status=RequestStatus.REJECTED).count()
    delivered_requests = requests_query.filter(status=RequestStatus.DELIVERED).count()
    
    # محاسبه درصدها
    pending_percent = round((pending_requests / total_requests * 100) if total_requests > 0 else 0)
    approved_percent = round((approved_requests / total_requests * 100) if total_requests > 0 else 0)
    rejected_percent = round((rejected_requests / total_requests * 100) if total_requests > 0 else 0)
    delivered_percent = round((delivered_requests / total_requests * 100) if total_requests > 0 else 0)
    
    # گرفتن درخواست‌های اخیر
    recent_requests = requests_query.order_by('-created_at')[:10]
    
    # داده‌های نمودار شهر
    city_stats = requests_query.values('city').annotate(count=Count('id')).order_by('-count')[:10]
    city_names = [item['city'] for item in city_stats]
    city_counts = [item['count'] for item in city_stats]
    
    # هشدارها
    alerts = []
    
    # بررسی هشدارهای سیستم
    if pending_requests > total_requests * 0.5:  # اگر بیش از ۵۰٪ درخواست‌ها در انتظار باشند
        alerts.append({
            'type': 'warning',
            'icon': 'exclamation-triangle',
            'title': 'انباشت درخواست',
            'message': 'درصد بالایی از درخواست‌ها در انتظار بررسی هستند.'
        })
    
    return render(request, 'myapp/dashboard.html', {
        'total_requests': total_requests,
        'pending_count': pending_requests,
        'approved_count': approved_requests,
        'rejected_count': rejected_requests,
        'delivered_count': delivered_requests,
        'pending_percent': pending_percent,
        'approved_percent': approved_percent,
        'rejected_percent': rejected_percent,
        'delivered_percent': delivered_percent,
        'recent_requests': recent_requests,
        'city_names': json.dumps(city_names),
        'city_counts': json.dumps(city_counts),
        'cities': cities,
        'search_query': search_query,
        'status': status_filter,
        'city': city_filter,
        'start_date': date_from,
        'end_date': date_to,
        'alerts': alerts,
    })

@login_required
@manager_required
def user_management(request):
    user_profiles = UserProfile.objects.all().order_by('user__username')
    form = UserCreateForm()
    
    return render(request, 'myapp/user_management.html', {
        'user_profiles': user_profiles,
        'form': form
    })

@login_required
@manager_required
def add_user(request):
    if request.method == 'POST':
        form = UserCreateForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'کاربر جدید با موفقیت ایجاد شد.')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
    
    return redirect('user_management')

@login_required
@manager_required
def edit_user(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        user = get_object_or_404(User, id=user_id)
        role = request.POST.get('role')
        
        # Update user
        user.first_name = request.POST.get('first_name', '')
        user.last_name = request.POST.get('last_name', '')
        user.email = request.POST.get('email', '')
        user.save()
        
        # Update profile
        try:
            profile = UserProfile.objects.get(user=user)
            profile.role = role
            profile.save()
        except UserProfile.DoesNotExist:
            UserProfile.objects.create(user=user, role=role)
        
        messages.success(request, 'اطلاعات کاربر با موفقیت بروزرسانی شد.')
    
    return redirect('user_management')

@login_required
@manager_required
def delete_user(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        user = get_object_or_404(User, id=user_id)
        
        # Delete user
        try:
            user.delete()
            messages.success(request, 'کاربر با موفقیت حذف شد.')
        except Exception as e:
            messages.error(request, f'خطا در حذف کاربر: {str(e)}')
    
    return redirect('user_management')

@login_required
@manager_required
def product_management(request):
    products = Product.objects.all().order_by('name')
    
    if request.method == 'POST':
        name = request.POST.get('name')
        tariff = request.POST.get('tariff')
        product_id = request.POST.get('product_id')
        
        if product_id:
            # Edit existing product
            product = get_object_or_404(Product, id=product_id)
            product.name = name
            product.tariff = tariff
            product.save()
            messages.success(request, 'کالا با موفقیت ویرایش شد.')
        else:
            # Add new product
            Product.objects.create(name=name, tariff=tariff)
            messages.success(request, 'کالای جدید با موفقیت اضافه شد.')
        
        return redirect('product_management')
    
    return render(request, 'myapp/product_management.html', {
        'products': products
    })

@login_required
@manager_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    
    # Check if product is used in any request
    if CustomerRequest.objects.filter(product=product).exists():
        messages.error(request, 'این کالا در درخواست‌ها استفاده شده است و قابل حذف نیست.')
        return redirect('product_management')
    
    product.delete()
    messages.success(request, 'کالا با موفقیت حذف شد.')
    return redirect('product_management')

@login_required
@manager_required
def import_products(request):
    """Import products from Excel file"""
    success = import_products_from_excel()
    
    if success:
        messages.success(request, 'کالاها با موفقیت از فایل اکسل وارد شدند.')
    else:
        messages.error(request, 'خطا در وارد کردن کالاها از فایل اکسل.')
    
    return redirect('product_management')

@login_required
@manager_required
def reports(request):
    # Get filter parameters
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    status = request.GET.get('status')
    province = request.GET.get('province')
    
    # Base queryset
    requests = CustomerRequest.objects.all()
    
    # Apply filters
    if start_date:
        try:
            # بررسی اینکه آیا تاریخ میلادی است یا شمسی
            if '/' in start_date:  # فرمت شمسی
                gregorian_date = jalali_to_gregorian(start_date)
                if gregorian_date:
                    requests = requests.filter(created_at__date__gte=gregorian_date)
                    # ذخیره تاریخ معادل شمسی برای نمایش
                    start_date = gregorian_to_jalali(gregorian_date)
            else:  # فرض میلادی
                start_date_obj = datetime.strptime(start_date, '%Y-%m-%d').date()
                requests = requests.filter(created_at__date__gte=start_date_obj)
                # تبدیل به شمسی برای نمایش
                start_date = gregorian_to_jalali(start_date_obj)
        except ValueError:
            pass
    
    if end_date:
        try:
            # بررسی اینکه آیا تاریخ میلادی است یا شمسی
            if '/' in end_date:  # فرمت شمسی
                gregorian_date = jalali_to_gregorian(end_date)
                if gregorian_date:
                    requests = requests.filter(created_at__date__lte=gregorian_date)
                    # ذخیره تاریخ معادل شمسی برای نمایش
                    end_date = gregorian_to_jalali(gregorian_date)
            else:  # فرض میلادی
                end_date_obj = datetime.strptime(end_date, '%Y-%m-%d').date()
                requests = requests.filter(created_at__date__lte=end_date_obj)
                # تبدیل به شمسی برای نمایش
                end_date = gregorian_to_jalali(end_date_obj)
        except ValueError:
            pass
    
    if status:
        requests = requests.filter(status=status)
    
    if province:
        requests = requests.filter(province=province)
    
    # Get unique provinces for filter
    provinces = CustomerRequest.objects.values_list('province', flat=True).distinct()
    
    # Paginate results
    paginator = Paginator(requests.order_by('-created_at'), 20)
    page = request.GET.get('page')
    requests_page = paginator.get_page(page)
    
    return render(request, 'myapp/reports.html', {
        'requests': requests_page,
        'provinces': provinces,
        'statuses': RequestStatus.choices,
        'filters': {
            'start_date': start_date,
            'end_date': end_date,
            'status': status,
            'province': province,
        }
    })

@login_required
@manager_required
def export_report(request):
    """Export report as CSV"""
    import csv
    
    # Get filter parameters
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    status = request.GET.get('status')
    province = request.GET.get('province')
    
    # Base queryset
    requests = CustomerRequest.objects.all()
    
    # Apply filters
    if start_date:
        try:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            requests = requests.filter(created_at__date__gte=start_date)
        except ValueError:
            pass
    
    if end_date:
        try:
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
            requests = requests.filter(created_at__date__lte=end_date)
        except ValueError:
            pass
    
    if status:
        requests = requests.filter(status=status)
    
    if province:
        requests = requests.filter(province=province)
    
    # Create CSV response
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="report.csv"'
    response.write('\ufeff')  # BOM for Excel to detect UTF-8
    
    writer = csv.writer(response)
    writer.writerow([
        'کد یکتا', 'نام', 'نام خانوادگی', 'کد ملی', 'استان', 'شهر',
        'نام کالا', 'تعداد/وزن', 'تاریخ ثبت', 'وضعیت'
    ])
    
    for req in requests:
        writer.writerow([
            req.unique_code,
            req.first_name,
            req.last_name,
            req.national_id,
            req.province,
            req.city,
            req.product.name,
            req.quantity,
            gregorian_to_jalali_datetime(req.created_at),
            req.get_status_display()
        ])
    
    return response

@login_required
@manager_required
def all_requests(request):
    search_query = request.GET.get('search', '')
    status_filter = request.GET.get('status', '')
    
    # Get all requests with filters
    requests_list = CustomerRequest.objects.all()
    
    if status_filter:
        requests_list = requests_list.filter(status=status_filter)
    
    if search_query:
        requests_list = requests_list.filter(
            Q(first_name__icontains=search_query) | 
            Q(last_name__icontains=search_query) | 
            Q(national_id__icontains=search_query) | 
            Q(unique_code__icontains=search_query) |
            Q(product__name__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(requests_list.order_by('-created_at'), 20)
    page = request.GET.get('page')
    requests = paginator.get_page(page)
    
    return render(request, 'myapp/all_requests.html', {
        'requests': requests,
        'statuses': RequestStatus.choices,
        'current_status': status_filter,
        'search_query': search_query
    })

@login_required
@manager_required
def request_detail(request, request_id):
    request_obj = get_object_or_404(CustomerRequest, id=request_id)
    
    return render(request, 'myapp/request_detail.html', {
        'request_obj': request_obj
    })

@login_required
@assessor_required
def assessor_reports(request):
    """گزارش‌گیری عملکرد ارزیاب"""
    # تاریخ‌های فیلتر
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')
    
    # آمارهای کلی
    total_assessed = CustomerRequest.objects.filter(assessor=request.user).count()
    total_approved = CustomerRequest.objects.filter(assessor=request.user, status=RequestStatus.APPROVED).count()
    total_rejected = CustomerRequest.objects.filter(assessor=request.user, status=RequestStatus.REJECTED).count()
    
    # محاسبه زمان متوسط بررسی
    assessed_requests = CustomerRequest.objects.filter(
        assessor=request.user,
        status__in=[RequestStatus.APPROVED, RequestStatus.REJECTED]
    )
    
    # اگر فیلتر تاریخ داریم، اعمال می‌کنیم
    if date_from:
        try:
            date_from_obj = datetime.strptime(date_from, '%Y-%m-%d').date()
            assessed_requests = assessed_requests.filter(created_at__date__gte=date_from_obj)
        except ValueError:
            pass
    
    if date_to:
        try:
            date_to_obj = datetime.strptime(date_to, '%Y-%m-%d').date()
            assessed_requests = assessed_requests.filter(created_at__date__lte=date_to_obj)
        except ValueError:
            pass
    
    # بررسی بازه زمانی و نرخ تایید/رد
    time_diffs = []
    for req in assessed_requests:
        # اگر زمان آخرین بروزرسانی داشته باشیم
        if hasattr(req, 'modified_at'):
            time_diff = req.modified_at - req.created_at
            time_diffs.append(time_diff.total_seconds() / 3600)  # تبدیل به ساعت
    
    avg_assessment_time = 0
    if time_diffs:
        avg_assessment_time = sum(time_diffs) / len(time_diffs)
    
    # آمار ماهانه
    monthly_data = {}
    current_year = timezone.now().year
    
    for month in range(1, 13):
        # استفاده از timezone aware datetime در Django 5.2+
        month_start = timezone.make_aware(datetime(current_year, month, 1))
        if month < 12:
            month_end = timezone.make_aware(datetime(current_year, month + 1, 1)) - timedelta(seconds=1)
        else:
            month_end = timezone.make_aware(datetime(current_year + 1, 1, 1)) - timedelta(seconds=1)
        
        approved_count = CustomerRequest.objects.filter(
            assessor=request.user,
            status=RequestStatus.APPROVED,
            created_at__gte=month_start,
            created_at__lte=month_end
        ).count()
        
        rejected_count = CustomerRequest.objects.filter(
            assessor=request.user,
            status=RequestStatus.REJECTED,
            created_at__gte=month_start,
            created_at__lte=month_end
        ).count()
        
        monthly_data[month] = {
            'approved': approved_count,
            'rejected': rejected_count,
            'total': approved_count + rejected_count
        }
    
    # تبدیل به فرمت مناسب برای نمودار
    months = []
    approved_data = []
    rejected_data = []
    
    for month, data in monthly_data.items():
        month_name = {
            1: 'فروردین', 2: 'اردیبهشت', 3: 'خرداد', 4: 'تیر',
            5: 'مرداد', 6: 'شهریور', 7: 'مهر', 8: 'آبان',
            9: 'آذر', 10: 'دی', 11: 'بهمن', 12: 'اسفند'
        }[month]
        
        months.append(month_name)
        approved_data.append(data['approved'])
        rejected_data.append(data['rejected'])
    
    return render(request, 'myapp/assessor_reports.html', {
        'total_assessed': total_assessed,
        'total_approved': total_approved,
        'total_rejected': total_rejected,
        'avg_assessment_time': round(avg_assessment_time, 2),
        'approval_rate': round(total_approved / total_assessed * 100 if total_assessed > 0 else 0, 1),
        'monthly_data': monthly_data,
        'months': json.dumps(months),
        'approved_data': json.dumps(approved_data),
        'rejected_data': json.dumps(rejected_data),
        'filters': {
            'date_from': date_from,
            'date_to': date_to,
        }
    })
