from django.contrib import admin
from .models import Product, CustomerRequest, UserProfile

class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'tariff')
    search_fields = ('name',)

class CustomerRequestAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'product', 'status', 'created_at', 'unique_code')
    list_filter = ('status', 'province', 'city')
    search_fields = ('first_name', 'last_name', 'national_id', 'unique_code')
    readonly_fields = ('unique_code', 'created_at')

class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role')
    list_filter = ('role',)
    search_fields = ('user__username',)

admin.site.register(Product, ProductAdmin)
admin.site.register(CustomerRequest, CustomerRequestAdmin)
admin.site.register(UserProfile, UserProfileAdmin)
