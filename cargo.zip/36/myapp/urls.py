from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # Authentication URLs
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('logout/', views.logout_view, name='logout'),
    
    # Main pages
    path('', views.index, name='index'),
    
    # Staff URLs - Page 1
    path('customer-request/', views.customer_request, name='customer_request'),
    path('get-product-tariff/', views.get_product_tariff, name='get_product_tariff'),
    
    # Assessor URLs - Page 2
    path('assessment/', views.assessment_list, name='assessment_list'),
    path('assessment/<int:request_id>/', views.assessment_detail, name='assessment_detail'),
    path('assessment/preview/<int:request_id>/', views.assessment_preview, name='assessment_preview'),
    path('assessment/reports/', views.assessor_reports, name='assessor_reports'),
    
    # Warehouse URLs - Page 3
    path('warehouse/', views.warehouse_list, name='warehouse_list'),
    path('warehouse/<int:request_id>/', views.delivery_form, name='delivery_form'),
    path('warehouse/reports/', views.warehouse_reports, name='warehouse_reports'),
    
    # Manager URLs - Page 4
    path('dashboard/', views.dashboard, name='dashboard'),
    path('users/', views.user_management, name='user_management'),
    path('users/add/', views.add_user, name='add_user'),
    path('users/edit/', views.edit_user, name='edit_user'),
    path('users/delete/', views.delete_user, name='delete_user'),
    
    path('products/', views.product_management, name='product_management'),
    path('products/delete/<int:product_id>/', views.delete_product, name='delete_product'),
    path('products/import/', views.import_products, name='import_products'),
    
    path('reports/', views.reports, name='reports'),
    path('reports/export/', views.export_report, name='export_report'),
    
    path('requests/', views.all_requests, name='all_requests'),
    path('requests/<int:request_id>/', views.request_detail, name='request_detail'),
] 