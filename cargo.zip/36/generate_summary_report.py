import os
import csv
import matplotlib.pyplot as plt
import pandas as pd
from collections import Counter

# Function to read CSV files
def read_csv(filename):
    data = []
    with open(filename, 'r', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            data.append(row)
    return data

# Create output directory for reports
report_dir = 'report'
if not os.path.exists(report_dir):
    os.makedirs(report_dir)

# Get all CSV files in the categorized_products directory
categorized_dir = 'categorized_products'
category_files = [f for f in os.listdir(categorized_dir) if f.endswith('_products.csv')]

# Initialize data structures for analysis
category_counts = {}
tariff_categories = {}

# Process each category file
for filename in category_files:
    filepath = os.path.join(categorized_dir, filename)
    data = read_csv(filepath)
    
    if 'tariff_' in filename:
        # This is a tariff-based category
        tariff_prefix = filename.replace('tariff_', '').replace('_products.csv', '')
        tariff_categories[tariff_prefix] = len(data)
    else:
        # This is a keyword-based category
        category = filename.replace('_products.csv', '')
        category_counts[category] = len(data)

# Generate summary report text
with open(os.path.join(report_dir, 'summary_report.txt'), 'w', encoding='utf-8') as f:
    f.write("Product Database Analysis Summary Report\n")
    f.write("======================================\n\n")
    
    # Write category statistics
    f.write("Product Categories by Keywords:\n")
    f.write("--------------------------\n")
    total_categorized = sum(count for category, count in category_counts.items() if category != 'uncategorized')
    for category, count in sorted(category_counts.items(), key=lambda x: x[1], reverse=True):
        if category != 'uncategorized':
            f.write(f"{category}: {count} products ({count/total_categorized*100:.1f}%)\n")
    
    f.write(f"\nTotal categorized products: {total_categorized}\n")
    if 'uncategorized' in category_counts:
        f.write(f"Uncategorized products: {category_counts['uncategorized']}\n")
    
    # Write tariff statistics
    f.write("\nProduct Categories by Tariff Code Prefix:\n")
    f.write("-------------------------------------\n")
    total_tariff = sum(tariff_categories.values())
    
    # Group tariff categories for better readability
    tariff_groups = {}
    for prefix, count in tariff_categories.items():
        # Convert prefix to int for numerical comparison
        prefix_int = int(prefix)
        
        # Assign group based on prefix range
        if prefix_int < 30:
            group = "Food and Beverages (01-29)"
        elif prefix_int < 40:
            group = "Chemicals (30-39)"
        elif prefix_int < 50:
            group = "Plastics and Rubber (40-49)"
        elif prefix_int < 64:
            group = "Textiles and Clothing (50-63)"
        elif prefix_int < 70:
            group = "Footwear and Headgear (64-69)"
        elif prefix_int < 84:
            group = "Stone, Glass, Metals (70-83)"
        elif prefix_int < 90:
            group = "Machinery and Electronics (84-89)"
        else:
            group = "Miscellaneous (90-99)"
        
        if group not in tariff_groups:
            tariff_groups[group] = 0
        tariff_groups[group] += count
    
    # Write tariff group statistics
    for group, count in sorted(tariff_groups.items(), key=lambda x: x[1], reverse=True):
        f.write(f"{group}: {count} products ({count/total_tariff*100:.1f}%)\n")
    
    # Write detailed tariff prefix statistics
    f.write("\nDetailed Tariff Prefix Breakdown:\n")
    f.write("-----------------------------\n")
    for prefix, count in sorted(tariff_categories.items(), key=lambda x: int(x[0])):
        f.write(f"Tariff prefix {prefix}: {count} products ({count/total_tariff*100:.1f}%)\n")

# Attempt to create visualizations if matplotlib is available
try:
    # Create category distribution pie chart
    categories = [cat for cat in category_counts.keys() if cat != 'uncategorized']
    values = [category_counts[cat] for cat in categories]
    
    plt.figure(figsize=(10, 6))
    plt.pie(values, labels=categories, autopct='%1.1f%%')
    plt.title('Distribution of Products by Category')
    plt.savefig(os.path.join(report_dir, 'category_distribution.png'))
    
    # Create tariff group bar chart
    groups = list(tariff_groups.keys())
    counts = list(tariff_groups.values())
    
    plt.figure(figsize=(12, 6))
    plt.bar(groups, counts)
    plt.title('Products by Tariff Group')
    plt.xlabel('Tariff Group')
    plt.ylabel('Number of Products')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, 'tariff_groups.png'))
    
    print("Visualization charts created successfully.")
except ImportError:
    print("Matplotlib not available. Skipping visualization generation.")
except Exception as e:
    print(f"Error generating visualizations: {str(e)}")

print(f"Summary report generated in the '{report_dir}' directory.")

# Try to display the summary report
try:
    with open(os.path.join(report_dir, 'summary_report.txt'), 'r', encoding='utf-8') as f:
        print("\nSUMMARY REPORT PREVIEW:\n")
        print(f.read())
except Exception as e:
    print(f"Error displaying report: {str(e)}") 