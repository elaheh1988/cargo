import pandas as pd

# Create a DataFrame with sample product data
products = [
    {"name": "تلویزیون سامسونگ 55 اینچ", "tariff": 5000000},
    {"name": "یخچال ال جی", "tariff": 8000000},
    {"name": "ماشین لباسشویی بوش", "tariff": 6500000},
    {"name": "کولر گازی اسپلیت", "tariff": 4500000},
    {"name": "اجاق گاز فردار", "tariff": 3000000},
    {"name": "جاروبرقی", "tariff": 1500000},
    {"name": "مایکروویو", "tariff": 2000000},
    {"name": "ماشین ظرفشویی", "tariff": 7000000},
    {"name": "پنکه سقفی", "tariff": 800000},
    {"name": "پلوپز", "tariff": 600000},
]

# Create DataFrame
df = pd.DataFrame(products)

# Save to Excel
df.to_excel("products.xlsx", index=False)

print("Excel file created successfully!") 