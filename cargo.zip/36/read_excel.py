from openpyxl import load_workbook

# Load the workbook
wb = load_workbook('product.xlsx')

# Get the active worksheet
ws = wb.active

# Print worksheet info
print(f'Worksheet name: {ws.title}')
print(f'Number of rows: {ws.max_row}')
print(f'Number of columns: {ws.max_column}')

# Print headers
headers = [cell.value for cell in ws[1]]
print("\nHeaders:", headers)

# Print first 5 rows of data
print("\nFirst 5 rows of data:")
for row_idx, row in enumerate(ws.iter_rows(min_row=2, max_row=6, values_only=True), 2):
    print(f"Row {row_idx}:", row) 