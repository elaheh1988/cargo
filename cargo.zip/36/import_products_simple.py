import os
import django
import csv
from decimal import Decimal

# تنظیم محیط جنگو
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myproject.settings')
django.setup()

from myapp.models import Product

def import_products_from_csv(csv_file):
    """
    وارد کردن محصولات از فایل CSV
    """
    print(f"در حال خواندن فایل CSV {csv_file}...")
    
    try:
        products_added = 0
        products_updated = 0
        
        with open(csv_file, 'r', encoding='utf-8') as f:
            # خواندن محتوای فایل
            content = f.readlines()
            if len(content) > 0:
                # بررسی و اصلاح سطر سرستون‌ها
                header = content[0].strip()
                if header == "nameariff":
                    # اصلاح سرستون‌ها
                    headers = ["name", "tariff"]
                    data_rows = content[1:]
                else:
                    # سرستون‌ها درست هستند
                    headers = header.split(',')
                    data_rows = content[1:]
                
                # پردازش سطرها
                for index, row_text in enumerate(data_rows):
                    try:
                        # اگر جداکننده کاما باشد
                        if ',' in row_text:
                            row_values = row_text.strip().split(',')
                            row = dict(zip(headers, row_values))
                        else:
                            # اگر جداکننده دیگری باشد یا ستون‌ها با طول ثابت باشند
                            # فرض می‌کنیم ستون اول نام محصول و ستون دوم تعرفه است
                            row_text = row_text.strip()
                            # جدا کردن نام محصول و تعرفه
                            name_part = row_text
                            tariff_part = "0"
                            
                            # تلاش برای پیدا کردن عدد در انتهای متن
                            digits = ""
                            for char in reversed(row_text):
                                if char.isdigit():
                                    digits = char + digits
                                elif digits:
                                    break
                            
                            if digits:
                                # اگر عدد در انتهای متن پیدا شد، آن را به عنوان تعرفه در نظر می‌گیریم
                                tariff_part = digits
                                name_part = row_text[:-len(digits)].strip()
                            
                            row = {"name": name_part, "tariff": tariff_part}
                        
                        # دریافت مقادیر ستون‌ها
                        name = row.get('name', '').strip()
                        
                        try:
                            tariff = Decimal(row.get('tariff', '0').strip())
                        except:
                            tariff = Decimal('0')
                        
                        if not name:
                            print(f"ردیف {index+2}: نام محصول خالی است. این ردیف رد شد.")
                            continue
                        
                        # بررسی وجود محصول با نام مشابه
                        product, created = Product.objects.update_or_create(
                            name=name,
                            defaults={
                                'tariff': tariff
                            }
                        )
                        
                        if created:
                            products_added += 1
                            print(f"محصول '{name}' با موفقیت اضافه شد.")
                        else:
                            products_updated += 1
                            print(f"محصول '{name}' بروزرسانی شد.")
                            
                    except Exception as e:
                        print(f"خطا در ردیف {index+2}: {str(e)}")
        
        print(f"\nعملیات واردسازی با موفقیت انجام شد.")
        print(f"تعداد {products_added} محصول جدید اضافه شد.")
        print(f"تعداد {products_updated} محصول بروزرسانی شد.")
        
    except Exception as e:
        print(f"خطا در خواندن فایل CSV: {str(e)}")

if __name__ == '__main__':
    csv_file = 'product1.csv'
    
    if os.path.exists(csv_file):
        import_products_from_csv(csv_file)
    else:
        print(f"خطا: فایل {csv_file} یافت نشد.") 