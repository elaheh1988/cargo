import os
import django
import openpyxl
from decimal import Decimal

# تنظیم محیط جنگو
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myproject.settings')
django.setup()

from myapp.models import Product

def import_products_from_excel(excel_file):
    """
    وارد کردن محصولات از فایل اکسل
    """
    print(f"در حال خواندن فایل اکسل {excel_file}...")
    
    try:
        # خواندن فایل اکسل
        workbook = openpyxl.load_workbook(excel_file)
        sheet = workbook.active
        
        # خواندن سرستون‌ها
        headers = [cell.value for cell in sheet[1]]
        
        products_added = 0
        products_updated = 0
        
        # پیمایش ردیف‌های دیتافریم (از ردیف 2 به بعد)
        for row_idx, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), 2):
            try:
                # ساخت دیکشنری از ردیف
                row_data = {headers[i]: row[i] for i in range(len(headers)) if i < len(row)}
                
                # دریافت مقادیر ستون‌ها
                name = str(row_data.get('name', '')) if row_data.get('name') else ''
                code = str(row_data.get('code', '')) if row_data.get('code') else ''
                category = str(row_data.get('category', '')) if row_data.get('category') else ''
                subcategory = str(row_data.get('subcategory', '')) if row_data.get('subcategory') else ''
                brand = str(row_data.get('brand', '')) if row_data.get('brand') else ''
                
                try:
                    price = Decimal(str(row_data.get('price', '0')))
                except:
                    price = Decimal('0')
                    
                try:
                    tariff = Decimal(str(row_data.get('tariff', '0')))
                except:
                    tariff = Decimal('0')
                
                if not name or name == 'nan' or name == 'None':
                    print(f"ردیف {row_idx}: نام محصول خالی است. این ردیف رد شد.")
                    continue
                
                # بررسی وجود محصول با نام مشابه
                product, created = Product.objects.update_or_create(
                    name=name,
                    defaults={
                        'code': code,
                        'category': category,
                        'subcategory': subcategory,
                        'brand': brand,
                        'price': price,
                        'tariff': tariff
                    }
                )
                
                if created:
                    products_added += 1
                    print(f"محصول '{name}' با موفقیت اضافه شد.")
                else:
                    products_updated += 1
                    print(f"محصول '{name}' بروزرسانی شد.")
                    
            except Exception as e:
                print(f"خطا در ردیف {row_idx}: {str(e)}")
        
        print(f"\nعملیات واردسازی با موفقیت انجام شد.")
        print(f"تعداد {products_added} محصول جدید اضافه شد.")
        print(f"تعداد {products_updated} محصول بروزرسانی شد.")
        
    except Exception as e:
        print(f"خطا در خواندن فایل اکسل: {str(e)}")

if __name__ == '__main__':
    excel_file = 'product1.xlsx'
    
    if os.path.exists(excel_file):
        import_products_from_excel(excel_file)
    else:
        print(f"خطا: فایل {excel_file} یافت نشد.") 