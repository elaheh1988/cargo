from openpyxl import load_workbook
import re

# Load the workbook
wb = load_workbook('product.xlsx')
ws = wb.active

# Get all data rows (skipping the header)
data_rows = list(ws.iter_rows(min_row=2, values_only=True))

# Total number of products
total_products = len(data_rows)
print(f"Total number of products: {total_products}")

# Group products by tariff code prefix
tariff_groups = {}
for row in data_rows:
    product_name, tariff_code, index = row
    
    # Get first two digits of tariff code as category
    if tariff_code and isinstance(tariff_code, (int, float)):
        category = str(int(tariff_code))[:2]
        if category not in tariff_groups:
            tariff_groups[category] = []
        tariff_groups[category].append(product_name)

# Print tariff groups statistics
print("\nProduct categories by tariff code prefix:")
for category, products in sorted(tariff_groups.items()):
    print(f"Category {category}: {len(products)} products")

# Find products with specific keywords
fruits = []
vegetables = []
meat = []
dairy = []

# Define Arabic/Persian keywords for categories
fruit_keywords = ['آناناس', 'سیب', 'پرتقال', 'انگور', 'میوه']
vegetable_keywords = ['مارچوبه', 'لوبیا', 'عدس', 'سبزیجات']
meat_keywords = ['گوشت', 'مرغ', 'ماهی']
dairy_keywords = ['شیر', 'پنیر', 'ماست']

# Categorize products
for row in data_rows:
    product_name, _, _ = row
    if not product_name:
        continue
        
    # Check if product contains keywords
    if any(keyword in product_name for keyword in fruit_keywords):
        fruits.append(product_name)
    if any(keyword in product_name for keyword in vegetable_keywords):
        vegetables.append(product_name)
    if any(keyword in product_name for keyword in meat_keywords):
        meat.append(product_name)
    if any(keyword in product_name for keyword in dairy_keywords):
        dairy.append(product_name)

# Print product category statistics
print("\nProduct categories by keywords:")
print(f"Fruits: {len(fruits)} products")
print(f"Vegetables: {len(vegetables)} products")
print(f"Meat products: {len(meat)} products")
print(f"Dairy products: {len(dairy)} products")

# Print sample products from each category
def print_samples(category_name, products, count=5):
    if products:
        sample = products[:min(count, len(products))]
        print(f"\nSample {category_name} products:")
        for product in sample:
            print(f"- {product}")

print_samples("fruit", fruits)
print_samples("vegetable", vegetables)
print_samples("meat", meat)
print_samples("dairy", dairy) 